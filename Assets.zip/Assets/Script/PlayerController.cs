using UnityEngine;
using System.Collections;
public class PlayerController : MonoBehaviour
{
    private Animator animator;

  
    void Start()
    {
       animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKey(KeyCode.W))
        {
            transform.Translate(Vector3.forward * GameManager.instance.PlayerSpeed * Time.deltaTime);
            animator.SetTrigger("Forward");
        }
        if(Input.GetKey(KeyCode.S))
        {
            transform.Translate(Vector3.back * GameManager.instance.PlayerSpeed * Time.deltaTime);
            animator.SetTrigger("Backward");
        }
        if(Input.GetKey(KeyCode.A))
        {
            transform.Translate(Vector3.left * GameManager.instance.PlayerSpeed * Time.deltaTime);
                animator.SetTrigger("left");
        }
        if(Input.GetKey(KeyCode.D))
        {
            transform.Translate(Vector3.right * GameManager.instance.PlayerSpeed * Time.deltaTime);
            animator.SetTrigger("right");
        }
        if(!Input.GetKey(KeyCode.W) && !Input.GetKey(KeyCode.S) && !Input.GetKey(KeyCode.A) && !Input.GetKey(KeyCode.D))
        {
            animator.SetTrigger("Idle");
        }
    }
}
